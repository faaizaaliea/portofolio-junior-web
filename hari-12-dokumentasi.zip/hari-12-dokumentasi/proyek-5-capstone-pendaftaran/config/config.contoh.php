<?php
/**
 * Contoh konfigurasi. SALIN menjadi config/config.php lalu sesuaikan.
 * config/config.php diabaikan git (berisi kredensial)  jangan di-commit.
 */
return [
    'host'    => 'localhost',
    'nama_db' => 'db_pelatihan',
    'user'    => 'root',
    'sandi'   => '',
    // true = tampilkan detail galat di layar (HANYA untuk pengembangan).
    // Untuk penggunaan sebenarnya isi false; detail tetap masuk storage/log/app.log.
    'debug'   => false,
];
