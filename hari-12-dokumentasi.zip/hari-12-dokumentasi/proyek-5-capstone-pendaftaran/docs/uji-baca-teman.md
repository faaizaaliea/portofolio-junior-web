# Uji Baca Teman (isi sendiri)

Tukar `docs/` dengan teman. Ia mencoba memahami modul `auth` **hanya dari dokumen** (`docs/modul/auth.md`, `docs/api/`), lalu memberi 3 pertanyaan yang tidak terjawab.

| No | Pertanyaan dari teman | Jawaban/perbaikan dokumen |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |

Nama teman: ____  Tanggal: ____
