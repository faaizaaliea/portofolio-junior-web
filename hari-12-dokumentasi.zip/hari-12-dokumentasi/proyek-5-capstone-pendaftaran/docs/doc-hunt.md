# Doc Hunt

> Tabel Doc Hunt resmi memakai repositori contoh dari instruktur **isi tabel itu sendiri** di bagian B. Bagian A berisi masalah dokumentasi nyata yang ditemukan dan diperbaiki pada proyek ini sendiri (bisa dipakai sebagai bahan/format).

## A. Temuan pada dokumentasi proyek Hari 11 → diperbaiki di v1.0.0

| No  | Masalah dokumentasi                                                                                         | Dampak                                                                               | Perbaikan                                                           |
| --- | ----------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------- |
| 1   | `skema.sql` tidak memuat tabel `admin` (hanya di `migrasi-hari11.sql`) dan tidak ada README                 | Instalasi dari nol gagal di langkah buat admin                                       | `skema.sql` lengkap + README langkah instalasi                      |
| 2   | `config.contoh.php` berisi `debug => true` dan kunci `admin_password_hash` yang tak dipakai                 | Pengguna mengira hash perlu diisi; detail galat bocor ke layar                       | `debug => false`, kunci dihapus, komentar ditulis ulang             |
| 3   | `kasus-uji.md`: ringkasan "12 pengujian otomatis" dan "27 lolos" tanpa hasil per kasus                      | Tidak dapat diverifikasi                                                             | Tiga kolom hasil per kasus + ringkasan yang dapat ditelusuri        |
| 4   | `laporan-bug.md`: BUG-13 berisi placeholder, semua Re-test "Belum", catatan "folder tests tidak ada di zip" | Laporan tampak belum selesai                                                         | BUG-13…18 nyata; Re-test hanya diisi bila benar-benar dijalankan    |
| 5   | Komentar `// BUG-05:` / `// BUG-01:` menempel di kode produksi                                              | Komentar mengacu ke laporan yang bisa berubah; menjelaskan _riwayat_, bukan _alasan_ | Diganti komentar alasan ("penguncian kedaluwarsa setelah 15 menit") |
| 6   | Fungsi tanpa DocBlock; indentasi `pendaftar.php`/`helpers.php` hilang                                       | Sulit dibaca; generator tak menghasilkan referensi                                   | DocBlock dengan `@param/@return/@throws`; kode dirapikan            |
| 7   | `composer.json` memakai `"*"`                                                                               | Versi bisa melompat saat `composer update`                                           | Batas `^3.1` dan `^1.8`; `composer.lock` disegarkan                 |

## B. Doc Hunt dari instruktur (isi sendiri)

| No  | Masalah dokumentasi | Dampak | Perbaikan |
| --- | ------------------- | ------ | --------- |
| 1   |                     |        |           |
| 2   |                     |        |           |
| 3   |                     |        |           |
