# Panduan Pengguna

## Untuk peserta
1. Buka `…/public/daftar.php`.
2. Isi **Nama** (3–100 karakter), **Email**, **No HP** (diawali 08, 10–13 digit), pilih **Kelas** (sisa kursi tampil di dalam tanda kurung), alamat opsional.
3. Klik **Simpan**. Bila ada isian salah, pesan merah muncul di bawah kolom terkait.
4. Pesan "Pendaftaran berhasil" menandakan data tersimpan. Bila muncul "Kuota kelas sudah penuh", pilih kelas lain.

![Form pendaftaran](gambar/01-form-pendaftaran.png)
![Validasi](gambar/02-validasi-nama.png)
![Kuota penuh](gambar/03-kuota-penuh.png)

Bukti pendaftaran (PDF) dicetak oleh admin; hubungi admin bila membutuhkannya.

## Untuk admin
**Masuk.** Buka `…/public/login.php`, isi username dan kata sandi. Lima kali salah berturut-turut mengunci login 15 menit.

![Login](gambar/04-login-admin.png)
![Login gagal](gambar/05-login-gagal.png)

**Daftar pendaftar.** Setelah login Anda melihat tabel pendaftar. Gunakan kotak *Cari* untuk mencari, klik judul kolom untuk mengurutkan, dan **Filter kelas** untuk menampilkan satu kelas. Kotak kuning menunjukkan kelas yang hampir penuh.

![Panel admin](gambar/06-panel-admin.png)

**Tambah / ubah.** Menu *Tambah Pendaftar* atau tombol *Ubah*. Memindahkan pendaftar ke kelas yang penuh akan ditolak.

**Hapus.** Tombol *Hapus* → konfirmasi → *Ya, hapus*. Penghapusan permanen.

![Konfirmasi hapus](gambar/07-konfirmasi-hapus.png)

**Cetak bukti.** Tombol *Cetak* membuka PDF bukti bernomor `REG-tahun-nomor` di tab baru.

![Bukti PDF](gambar/13-bukti-pdf.png)

**Kelas.** Menu *Kelas*: tambah kelas (nama unik, kuota 1–1000), ubah (kuota tidak boleh di bawah jumlah pendaftar), hapus (hanya kelas tanpa pendaftar).

**Keluar.** Tombol *Logout* (menutup sesi).

## Pesan galat umum
| Pesan | Arti / tindakan |
| --- | --- |
| Username atau kata sandi salah. | Periksa ejaan; ada batas 5 percobaan |
| Terlalu banyak percobaan… | Tunggu sesuai menit yang tertera |
| Email sudah terdaftar. | Pakai email lain atau cari data yang sudah ada |
| Kuota kelas sudah penuh. | Pilih kelas lain atau minta admin menaikkan kuota |
| Kelas tidak dapat dihapus karena masih memiliki pendaftar. | Pindahkan/hapus pendaftarnya dulu |
| Permintaan tidak valid. (403) | Muat ulang halaman lalu ulangi (token CSRF kedaluwarsa) |
| Terjadi kesalahan pada sistem. | Lihat `storage/log/app.log` |
