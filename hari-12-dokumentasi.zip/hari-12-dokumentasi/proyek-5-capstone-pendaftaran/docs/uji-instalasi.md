# Uji Instalasi dari Nol

## A. Dijalankan di sandbox (2026-11-04) bukan pengganti uji Anda

Lingkungan: PHP 8.3.6, MariaDB 10.11, `php -S` (bukan XAMPP). Langkah: basis data kosong → impor `database/skema.sql` + `data-contoh.sql` → `config.php` dari contoh → `buat-admin.php` → server → `tests/uji-http.sh` (43 lolos) + `tests/jalankan.php` (50 lolos) + PDF Dompdf dan FPDF terbuka (1 halaman, "REG-2026-000001").
**Tidak teruji:** `composer install` (paket Packagist tidak dapat dijangkau dari sandbox; `vendor/` Hari 11 yang dipakai) dan tampilan CDN/JS di browser.

## B. Uji Anda (wajib, sesuai T8)

```
git clone <URL-repo> uji-instalasi      # ke htdocs/uji-instalasi
```

Ikuti README **apa adanya** pada basis data baru (mis. `db_pelatihan` dihapus dulu). Catat:

| Langkah README     | Berhasil? | Masalah / yang tidak jelas | Perbaikan README |
| ------------------ | --------- | -------------------------- | ---------------- |
| 1 Salin proyek     |           |                            |                  |
| 2 Impor skema      |           |                            |                  |
| 3 config.php       |           |                            |                  |
| 4 composer install |           |                            |                  |
| 5 buat-admin       |           |                            |                  |
| 6 Buka aplikasi    |           |                            |                  |
