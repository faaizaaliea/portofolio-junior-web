# Peta Modul

Versi 1.0.0 seluruh berkas di `src/`, `config/`, dan `public/`.

## src/ dan config/

| Berkas                | ID modul    | Tanggung jawab                                         | Fungsi/kelas publik                                                                                                                                            |
| --------------------- | ----------- | ------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `src/bootstrap.php`   | MOD-BOT-001 | Sesi aman, muat konfigurasi & modul, exception handler | (tanpa fungsi; dimuat tiap halaman)                                                                                                                            |
| `config/database.php` | MOD-DB-001  | Koneksi PDO bersama                                    | `getConnection()`                                                                                                                                              |
| `src/helpers.php`     | MOD-HLP-001 | Escape, redirect, CSRF, flash, ambil id                | `e`, `redirect`, `tokenCsrf`, `cekCsrf`, `setFlash`, `ambilFlash`, `ambilIdPositif`                                                                            |
| `src/validasi.php`    | MOD-VAL-001 | Fungsi murni (mudah diuji)                             | `validNoHp`, `validNama`, `validKuota`, `sisaKuota`, `formatNomorBukti`, `amankanSelCsv`                                                                       |
| `src/kelas.php`       | MOD-KLS-001 | CRUD kelas + struktur data                             | `daftarKelas`, `daftarKelasDenganSisa`, `petaKelasById`, `kelasHampirPenuh`, `ambilKelas`, `validasiKelas`, `tambahKelas`, `ubahKelas`, `hapusKelas`           |
| `src/pendaftar.php`   | MOD-PND-001 | Query & validasi pendaftar                             | `ambilSemuaPendaftar`, `ambilPendaftarById`, `emailSudahAda`, `validasiPendaftar`, `tambahPendaftar`, `ubahPendaftar`, `hapusPendaftar`, `ambilBuktiPendaftar` |
| `src/kuota.php`       | MOD-KUO-001 | Kuota atomik (transaksi)                               | `KuotaPenuhException`, `hitungSisaKuota`, `pastikanAdaKursi`, `daftarkanDenganKuota`, `ubahDenganKuota`                                                        |
| `src/auth.php`        | MOD-AUT-001 | Login admin berbasis sesi                              | `cariAdmin`, `prosesLogin`, `adminSudahLogin`, `wajibLogin`, `logout`                                                                                          |
| `src/log.php`         | MOD-LOG-001 | Catatan peristiwa                                      | `catatLog`                                                                                                                                                     |

## public/ (halaman)

| Berkas                                           | Akses              | Fungsi                                                     |
| ------------------------------------------------ | ------------------ | ---------------------------------------------------------- |
| `daftar.php`                                     | publik             | Form pendaftaran peserta                                   |
| `login.php`, `logout.php`                        | publik / POST+CSRF | Masuk (kunci 15 menit setelah 5 gagal) / keluar            |
| `index.php`                                      | admin              | Tabel pendaftar, filter kelas, kelas hampir penuh          |
| `tambah.php`, `ubah.php`, `hapus.php`            | admin              | CRUD pendaftar (`hapus` hanya POST)                        |
| `kelas.php`, `kelas-form.php`, `kelas-hapus.php` | admin              | CRUD kelas                                                 |
| `cetak.php`, `cetak-fpdf.php`                    | admin              | Bukti PDF (Dompdf / FPDF)                                  |
| `_form.php`                                      | (partial)          | Form pendaftar bersama                                     |
| `js/app.js`, `js/validasi-form.js`               |                    | Toast, konfirmasi hapus, DataTables+filter; validasi klien |

## Lima fungsi: parameter dan output

| Fungsi                 | Parameter                                         | Output                                          | Exception                             |
| ---------------------- | ------------------------------------------------- | ----------------------------------------------- | ------------------------------------- |
| `daftarkanDenganKuota` | `PDO $pdo`, `array $data`                         | `bool` (false = email ganda)                    | `KuotaPenuhException`, `Throwable` DB |
| `ubahDenganKuota`      | `PDO`, `int $id`, `array $data`, `int $kelasLama` | `bool`                                          | `KuotaPenuhException`                 |
| `validasiPendaftar`    | `array $input`, `PDO`, `?int $idUbah`             | `['data'=>…,'galat'=>…]`                        |                                       |
| `prosesLogin`          | `PDO`, `string $username`, `string $sandi`        | `bool`; set `$_SESSION['admin_id']`             |                                       |
| `kelasHampirPenuh`     | `array $kelas`, `int $batas = 3`                  | array kelas terurut sisa kecil→besar (sisa > 0) |                                       |
