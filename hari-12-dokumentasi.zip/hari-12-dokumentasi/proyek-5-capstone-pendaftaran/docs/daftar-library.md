# Daftar Library

> Disusun ulang dari `composer.lock` dan tag `<script>/<link>` di `templates/`. Bila Anda punya `daftar-library.md` Hari 10 sendiri, samakan isinya (khususnya alasan memilih) sebelum pengumpulan.

| Library                                                                                                              | Versi                  | Lisensi                      | Sumber                 | Kegunaan                                | Dipakai di                           |
| -------------------------------------------------------------------------------------------------------------------- | ---------------------- | ---------------------------- | ---------------------- | --------------------------------------- | ------------------------------------ |
| Bootstrap                                                                                                            | 5.3.8                  | MIT                          | CDN jsDelivr           | Tata letak, form, tombol                | `templates/header.php`, `footer.php` |
| jQuery                                                                                                               | 3.7.1                  | MIT                          | CDN code.jquery.com    | Prasyarat DataTables                    | `footer.php` (halaman dengan tabel)  |
| DataTables (+ integrasi Bootstrap 5)                                                                                 | 1.13.11                | MIT                          | CDN cdn.datatables.net | Cari/urut/halaman tabel + filter kelas  | `index.php`, `js/app.js`             |
| SweetAlert2                                                                                                          | 11.26.25               | MIT                          | CDN jsDelivr           | Toast sukses & konfirmasi hapus         | `js/app.js`                          |
| Dompdf                                                                                                               | v3.1.6                 | LGPL-2.1                     | Composer               | Bukti PDF dari HTML (utama)             | `public/cetak.php`                   |
| FPDF                                                                                                                 | 1.9.0                  | Bebas pakai (lihat fpdf.org) | Composer               | Bukti PDF alternatif untuk perbandingan | `public/cetak-fpdf.php`              |
| Dependensi Dompdf: php-font-lib 1.0.2, php-svg-lib 1.0.2, masterminds/html5 2.12.0, sabberworm/php-css-parser v9.5.0 | sesuai `composer.lock` | LGPL/MIT                     | Composer               | Pendukung Dompdf                        | otomatis                             |

## Perbandingan Dompdf vs FPDF

| Aspek                      | Dompdf                             | FPDF                                      |
| -------------------------- | ---------------------------------- | ----------------------------------------- |
| Cara membuat               | HTML + CSS (`templates/bukti.php`) | Perintah `Cell`/`MultiCell`               |
| Karakter non-Latin (UTF-8) | Baik dengan font DejaVu            | Perlu konversi Windows-1252 (`teksPdf()`) |
| Ukuran/dependensi          | Besar                              | Satu berkas                               |
| Dipilih sebagai utama      | Ya templat HTML mudah dirawat      | Cadangan                                  |

## Catatan keamanan dan pemeliharaan

- Versi CDN dikunci pada angka tertentu (bukan `latest`). Tidak memakai SRI (integrity) keterbatasan yang diketahui.
- `composer.json` membatasi `dompdf/dompdf ^3.1` dan `setasign/fpdf ^1.8` (sebelumnya `*`); `composer.lock` menyimpan versi persis.
- Periksa pembaruan keamanan secara berkala: `composer outdated`.
