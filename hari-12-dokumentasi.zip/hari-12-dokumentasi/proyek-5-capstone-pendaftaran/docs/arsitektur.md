# Arsitektur

## Struktur folder
```
config/     config.contoh.php (salin → config.php), database.php (PDO)
src/        bootstrap, helpers, validasi, log, kelas, pendaftar, kuota, auth
public/     halaman (document root), js/
templates/  header.php, footer.php, bukti.php
database/   skema.sql, data-contoh.sql, buat-admin.php
storage/    log/app.log
tests/      jalankan.php, uji-http.sh
docs/       dokumentasi
```
Prinsip: **public/** hanya berisi alur halaman (ambil input → panggil fungsi `src/` → tampilkan); semua query dan aturan bisnis ada di **src/**; HTML bersama ada di **templates/**.

## Alur request (pendaftaran publik)
```mermaid
sequenceDiagram
    participant B as Browser
    participant D as public/daftar.php
    participant V as src/pendaftar.php
    participant K as src/kuota.php
    participant DB as MariaDB
    B->>D: POST nama, email, no_hp, kelas_id, csrf
    D->>D: cekCsrf()
    D->>V: validasiPendaftar()
    V->>DB: email ganda? kelas ada?
    D->>K: daftarkanDenganKuota()
    K->>DB: BEGIN; SELECT kuota FROM kelas FOR UPDATE
    K->>DB: COUNT(pendaftar kelas) < kuota ?
    alt masih ada kursi
        K->>DB: INSERT pendaftar; COMMIT
        D-->>B: 302 daftar.php?status=sukses (flash)
    else penuh
        K->>DB: ROLLBACK
        D-->>B: 200 form + "Kuota kelas sudah penuh."
    end
```

## ERD
```mermaid
erDiagram
    kelas ||--o{ pendaftar : "memiliki"
    kelas {
        int id PK
        varchar nama_kelas UK
        int kuota
    }
    pendaftar {
        int id PK
        varchar nama
        varchar email UK
        varchar no_hp
        text alamat
        int kelas_id FK
        timestamp tgl_daftar
    }
    admin {
        int id PK
        varchar username UK
        varchar password_hash
        timestamp dibuat_pada
    }
```
`pendaftar.kelas_id → kelas.id` dengan `ON DELETE RESTRICT` (kelas berisi pendaftar tak bisa dihapus). Tabel `admin` berdiri sendiri.

## Keamanan (ringkas)
PDO prepared statement (`EMULATE_PREPARES=false`); semua output lewat `e()`; token CSRF pada setiap POST; aksi mengubah data hanya POST; sesi httponly + SameSite=Lax + regenerasi ID saat login; `password_hash`; log tanpa data sensitif; `config/config.php` di-ignore git.

## Struktur data yang dipilih secara sadar
| Kebutuhan | Struktur dipilih | Alasan | Alternatif (dan mengapa tidak) |
| --- | --- | --- | --- |
| Menampilkan nama/kuota kelas untuk tiap baris tabel pendaftar (ratusan baris) | **Hash map** (array asosiatif) `petaKelasById()`: id → baris kelas | Pencarian per id O(1); dibangun sekali O(k) dari hasil satu query | Loop `foreach` per baris → O(n·k); query per baris → n query ke database (N+1) |
| Menampilkan beberapa kelas yang paling hampir penuh di dashboard | **Array terurut** `usort` pada `sisa` (lalu nama sebagai pemutus seri) + `array_slice`, lewat `kelasHampirPenuh()` | Jumlah kelas kecil (puluhan); pengurutan O(k log k) cukup dan mudah diuji; pemutus seri membuat urutan deterministik | `ORDER BY` di SQL: sah, tetapi data kelas sudah di memori dan aturan "sisa > 0" ikut diuji di PHP; `SplPriorityQueue`/heap: berlebihan untuk k kecil |
| Kunci pengunci kursi terakhir saat pendaftaran bersamaan | **Baris database terkunci** (`FOR UPDATE`) sebagai mutex | Satu sumber kebenaran; aman lintas proses PHP | Variabel/array di PHP: tidak dibagi antar request; berkas kunci: rapuh, tak terikat transaksi |
| Daftar flash sekali-tampil | String di `$_SESSION['flash']` yang dihapus saat dibaca (pola "ambil lalu buang") | Sederhana; satu pesan per redirect | Antrean `SplQueue`: perlu bila banyak pesan, belum dibutuhkan |

Bukti uji struktur data: `tests/jalankan.php` ("Hash map: lookup kelas per id", "Hampir penuh: kelas penuh (sisa 0) tidak ikut").
